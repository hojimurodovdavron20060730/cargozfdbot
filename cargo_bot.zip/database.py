import sqlite3

def init_db():
    conn = sqlite3.connect("tracks.db")
    c = conn.cursor()
    c.execute("CREATE TABLE IF NOT EXISTS tracks (code TEXT PRIMARY KEY, status TEXT)")
    c.execute("CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY)")
    c.execute("CREATE TABLE IF NOT EXISTS subs (track TEXT, user INTEGER, UNIQUE(track,user))")
    conn.commit()
    conn.close()

def add_track(code, status):
    conn = sqlite3.connect("tracks.db")
    c = conn.cursor()
    c.execute("INSERT OR IGNORE INTO tracks VALUES (?,?)", (code, status))
    conn.commit()
    conn.close()

def update_track(code, status):
    conn = sqlite3.connect("tracks.db")
    c = conn.cursor()
    c.execute("UPDATE tracks SET status=? WHERE code=?", (status, code))
    conn.commit()
    conn.close()

def get_status(code):
    conn = sqlite3.connect("tracks.db")
    c = conn.cursor()
    c.execute("SELECT status FROM tracks WHERE code=?", (code,))
    r = c.fetchone()
    conn.close()
    return r[0] if r else None

def add_user(user_id):
    conn = sqlite3.connect("tracks.db")
    c = conn.cursor()
    c.execute("INSERT OR IGNORE INTO users VALUES (?)", (user_id,))
    conn.commit()
    conn.close()

def add_subscriber(track, user_id):
    conn = sqlite3.connect("tracks.db")
    c = conn.cursor()
    c.execute("INSERT OR IGNORE INTO subs VALUES (?,?)", (track, user_id))
    conn.commit()
    conn.close()

def get_subscribers(track):
    conn = sqlite3.connect("tracks.db")
    c = conn.cursor()
    c.execute("SELECT user FROM subs WHERE track=?", (track,))
    users = [i[0] for i in c.fetchall()]
    conn.close()
    return users

def get_users():
    conn = sqlite3.connect("tracks.db")
    c = conn.cursor()
    c.execute("SELECT id FROM users")
    users = [i[0] for i in c.fetchall()]
    conn.close()
    return users
